function [B_H,SDF,q]=GeneratefBmRealization(X,nx,p1,p2,q0)
%USAGE:        GeneratefBmRealization(X,nx,p1,p2,q0)
%
%INPUTS:   
%        X =length of realization (meters) 
%        nx=number of samples
%        p1, p2 = small-scale, large-scale spectral index parameter
%        q0     = transition spatial wavenumber 2*pi/X<=q0<=pi/dx
%
%OUTPUTS:
%        B_H =fBm realization (1,nx)
%        SDF =Spectral Density Function  (1,nx/2)
%        q   =spatial wavenumber         (1,nx/2)
%---------------------------------------------------------------------------------
%
%Spatial wavenumber domain sampling
dkx=2*pi/X; kx=(-nx/2:nx/2-1)*dkx;
[~,nq02]=min(abs(kx-q0));
nq01=nx-nq02+2;
q0=kx(nq02); CF=sqrt(q0^(p2-p1));
%Generate inverse power-law weighting
F(1:nq01-1) =-1i*CF./(kx(1:nq01-1).^(p2/2));
F(nq02+1:nx)=-1i*CF./(kx(nq02+1:nx).^(p2/2));
F(nq01:nq02)=-1i./(kx(nq01:nq02).^(p1/2));
F(nx/2+1)=0;
SDF=abs(F(nx/2+2:nx)).^2;
q  =kx(nx/2+2:nx);

%Multiply by unit variance gaussian white noise
F=(randn(nx,1)+1i*randn(nx,1)).*F';
%Generate fBm structure
B_H=real(fftshift(ifft(fftshift(F)))); clear F
std_BH=mean(std(B_H));
B_H=B_H/std_BH;
B_H=B_H-mean(B_H);

return