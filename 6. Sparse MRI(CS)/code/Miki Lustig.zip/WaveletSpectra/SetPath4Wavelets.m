%Set Path for wavelet analysis
path2wavelets=fileparts(pwd);
%First activate Wavelab850 (Set global variables)
run([path2wavelets,'\Wavelets\Wavelab850\WavePath'])
%Add paths to wavelet utilities
addpath('WaveletScaleSpectraUtilities');