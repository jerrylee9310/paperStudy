%Wavelet Analysis Demo
%
clear
X=10000;  nx= 16384;    
p1=2; p2=3; q0=[];

NO=input('Input Example # 1, 2, 3, or 4 ');
switch NO
    case 1
        q0=2*pi/10000;         %one-component steep
    case 2
        q0=2*pi/100;           %two-component
    case 3
        q0=2*pi/100; p2=0;     %noise-limited 
    case 4
        q0=2*pi*nx/X;          %one-component shallow
end

DISPLAY=1;
PLOTID=['fBm p1=',num2str(p1),' p2=',num2str(p2),' q0=',num2str(log10(q0/2/pi))];

%Generate realization
[B_H,SDF,q]=GeneratefBmRealization(X,nx,p1,p2,q0);
[~,nq0]=min(abs(q-q0));
q=q/2/pi;
dx=X/nx;
span=(0:nx-1)*dx;
J=log2(length(B_H));

if ~isempty(DISPLAY)
    figure
    plot(log10(q),dB10(SDF),'r')
    hold on
    plot(log10(q(nq0)),dB10(SDF(nq0)),'rp')
    grid on
    xlabel('log10(q/(2\pi)')
    ylabel('dB')
    title('fBmSDF')
    bold_fig
    
    figure
    plot(span,B_H,'r')
    grid on
    xlabel('span')
    ylabel('fBm')
    title(PLOTID)
    bold_fig
end


%Wavelet Analysis
DISP=1; jmax=1;
while ~isempty(jmax)
    [SPEC_Summary]=WaveletAnalysis(B_H',dx,jmax,DISP);
    nsegs=length(SPEC_Summary);
    fprintf('%5i Segments \n',nsegs)
    DisplaySpectra(SPEC_Summary,PLOTID)
    jmax=input('New jmax>1 or CR ');
end
