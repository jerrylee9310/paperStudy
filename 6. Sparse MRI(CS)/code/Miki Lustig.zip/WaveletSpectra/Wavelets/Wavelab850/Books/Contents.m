% Books:Contents v$VERSION$ -- Books using Wavelab
%
% This directory contains code to reproduce books using WaveLab
%
% WaveTour - Figures of the book "A Wavelet Tour of Signal Processing"
%                                Stephane Mallat, Academic Press, 1998 
% 
% This book explains the applications of wavelets to signal processing.
