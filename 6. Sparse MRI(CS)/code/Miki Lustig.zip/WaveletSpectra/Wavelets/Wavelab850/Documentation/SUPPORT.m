% SUPPORT -- WaveLab Support
%
% This software has been developed as part of the research
% effort of the authors under various federally supported
% grants.  If you find that it does not work correctly,
% please e-mail a notification of your problem to WaveLab. 
% Use the format indicated in the file BUGREPORTS.m.
% 
% To the extent that we can isolate the problem and develop a
% solution, and to the extent that it fits in with our
% schedule with releasing a new version, we will attempt to
% fix the problem.
% 
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:40 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
