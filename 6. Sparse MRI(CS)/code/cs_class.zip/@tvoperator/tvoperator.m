function res = tvoperator()

res.adjoint = 0;

res = class(res,'tvoperator');
