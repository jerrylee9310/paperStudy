close all; clear all; clc;
%% load data
load im1.mat

%% Fig 1
% 1.image
im = im1;
im = im + 0.1*randn + 1i*0.1*randn;

% 2. k-space data
kdata = fft2c(im);

% 3. wavelet transform 
wdp = 4;
[a,h,v,d] = haart2(im,wdp);
wdata = a;
for i=wdp:-1:1
    wdata = [wdata h{i}; v{i} d{i}];
end
xrec = ihaart2(a,h,v,d); 


% 4. Random undersampling
under_mask = ones(size(im));
for i =1:300
    for j = 1:300
        ux = randi([1,size(im,1)]);
        uy = randi([1,size(im,1)]);
        under_mask(ux,uy) = 0;
    end
end
% under_mask = genrndmask(im,4,0.2);
under_k = kdata.*under_mask;
sample_ratio = sum(sum(under_mask)) / numel(im) * 100;

% 5. Incoherent artifacts on image space
under_im = ifft2c(under_k);

%% Plot
fprintf('Random undersampling ration : %.1f%% \n',sample_ratio);

figure(),
subplot(3,2,1); imagesc(abs(kdata),[1e1 1e3]); title('k-space');
subplot(3,2,2); imshow(abs(under_mask),[]); title('Undersampled mask');
subplot(3,2,3); imshow(abs(im),[]); title('Image');
subplot(3,2,4); imshow(abs(under_im),[]); title('Incoherent artifacts');
subplot(3,2,5); imshow(abs(wdata),[1e1 1e3]); title('Incoherent artifacts');
subplot(3,2,6); imagesc(abs(under_k),[1e1 1e3]); title('Undersampled k-space');

