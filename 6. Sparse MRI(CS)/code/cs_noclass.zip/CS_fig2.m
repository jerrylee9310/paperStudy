close all; clear all; clc;
%%
% sparse signal
ss = zeros(3,100);
ss(1,15) = 3; ss(2,65) = 7; ss(3,80) = 12;
% ss(1,15) = 3*(1+1i); ss(2,65) = 7*(1+1i); ss(3,80) = 12*(1+1i);

% k-space representation
kdata = zeros(3,100);
for i=1:3
    kdata(i,:) = fftshift(fft(ifftshift(ss(i,:))));
end

subplot(3,2,1), stem(sum(ss)); title('Sparse Signal');
subplot(3,2,2), plot([1:100],real(sum(kdata))); hold on; plot([1:100],imag(sum(kdata))); hold off; title('k-space of Sparse Signal');

%% Sanmpling process
% 1. equispace sampling
acc = 4;
eqmask = zeros(1,100);
eqmask(1:acc:100) = 1;
eqs = sum(kdata).*eqmask; 

% signals are overlapped. Esp. 1st and 2nd signal
eqss = acc*fftshift(ifft(ifftshift(eqs)));
subplot(3,2,3), stem(abs(eqss)); title('equispaced 4-fold u-sampling');

% 2. random sampling
flag = true;
rndpnt = [];
while flag
    rndpnt = [rndpnt randi([1,100])];
    if length(unique(rndpnt)) == 100/acc
        rndpnt = unique(rndpnt);
        flag = false;
    end
end
rndmask = zeros(1,100);
rndmask(rndpnt) = 1;
rds = sum(kdata).*rndmask;
rdss = acc*fftshift(ifft(ifftshift(rds)));
subplot(3,2,4), stem(abs(rdss)); title('random 4-fold u-sampling'); hold on;

%% calculate PSF(point spread function)
point = zeros(1,100);
point(51) = 1;
kpnt = fftshift(fft(ifftshift(point)));
psf = kpnt.*rndmask;
tpsf = acc*fftshift(ifft(ifftshift(psf)));
subplot(3,2,5), stem(abs(tpsf)); title('PSF');

%% iterative hard-thresholding method
rdsss = rdss;
thrs = zeros(3,1);
maxidx = zeros(3,1);
for i = 1:3
    % find max peak and max value of iteself
    [thrs(i),maxidx(i)] = max(rdsss);
    subplot(3,2,4), c1 = plot(repmat(abs(thrs(i)),100),'--');
    
    % calculate the interefence (E leakage)
    peak = zeros(1,100);
    peak(maxidx(i)) = thrs(i);
    itf = conv(peak,tpsf,'same');
    
    % subtract interefence
    rdsss = rdsss - itf;
    subplot(3,2,6), stem(abs(rdsss)); title('Interference subtraction data');
    delete(c1);
end

figure(), stem(sum(ss)); hold on; 
rec = zeros(1,100); rec(maxidx) = thrs;
stem(abs(rec));
    