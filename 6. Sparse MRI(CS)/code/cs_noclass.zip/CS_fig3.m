clear all; close all; clc;

% load im1; im = im1;
% im = phantom(256);
load brainsos;
im = img;

% normalising
im = im./max(abs(im(:)));

% noise adding
% im = im + 0.01*randn(size(im)) + 0.01i*randn(size(im));
%% Decomposition
% wavelet
wdp = 3;
[wc,ws]=wavedec2(im,wdp,'haar');

[H1,V1,D1] = detcoef2('all',wc,ws,1);
A1 = appcoef2(wc,ws,'haar',1); 
[H2,V2,D2] = detcoef2('all',wc,ws,2);
A2 = appcoef2(wc,ws,'haar',2); 
[H3,V3,D3] = detcoef2('all',wc,ws,3);
A3 = appcoef2(wc,ws,'haar',3); 
wdata = [A3 H3; V3 D3];
wdata = [wdata H2; V2 D2];
wdata = [wdata H1; V1 D1];
% figure('Name', 'wavelet image'), imshow(abs(wdata),[0 1]);


% finite difference
wdif = D(im);
tt = reshape(wdif(2:prod(size(im))+1),size(im));
tt2 = reshape(wdif(prod(size(im))+2:end),size(im));
tt3 = wdif(1) + tt + tt2;
% figure, imshow(abs(tt+tt2),[]);
% wdif(1) = 0;




% sort coefficients
idx_wav = sort(abs(wc(:)),'descend');
idx_diff = sort(abs(wdif(:)),'descend');

%% recon
c = 1;
pctg = [.01 .05 .1 .2 1];
for i = pctg
    % wavelet
    threswav = ceil(length(wc)*i);
    tmp_wav = wc(:).';
    tmp_wav(abs(tmp_wav)<idx_wav(threswav)) = 0;
    rec_wav(:,:,c) = waverec2(tmp_wav,ws,'haar');
    
    % finite difference
    thresdif = ceil(length(wdif)*i);
    tmp_dif = wdif(:);
    tmp_dif(abs(tmp_dif)<idx_diff(thresdif)) = 0;
    rec_dif(:,:,c) =  invD(tmp_dif,size(im));
    
    c = c+1;
end

tmp = [];
for n=1:length(pctg)
    tmp = cat(2,tmp,abs(cat(1,rec_wav(:,:,n),rec_dif(:,:,n))));
end
figure('Name','1st row : wavelet, 2nd row : difference'), imshow(tmp,[]), title('1%  5%  10%  20%  100%')


% edge region
zoomed = [];
xRange = [68:148];
yRange = [98:158];
for n=1:length(pctg)
    zoomed = cat(2,zoomed,abs(cat(1,rec_wav(xRange,yRange,n),rec_dif(xRange,yRange,n))));
end
figure('Name','1st row : wavelet, 2nd row : difference'), imshow(zoomed,[]), title('1%  5%  10%  20%  100%')

% smooth region
smth = [];
sxRange = [48:128];
syRange = [48:108];
for n=1:length(pctg)
    smth = cat(2,smth,abs(cat(1,rec_wav(sxRange,syRange,n),rec_dif(sxRange,syRange,n))));
end
figure('Name','1st row : wavelet, 2nd row : difference'), imshow(smth,[]), title('1%  5%  10%  20%  100%')
    