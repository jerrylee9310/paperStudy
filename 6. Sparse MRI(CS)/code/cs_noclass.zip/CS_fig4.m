clear all; close all; clc;
%% ramdom mask generation // from fig.1
flag = true;
rndmask = zeros(100,100);
smprt = 0.1; % means acc = 5 = 1/smprt
while flag
    ux = randi([1,100]);
    uy = randi([1,100]);
    rndmask(ux,uy) = 1;
    if sum(sum(rndmask)) == numel(rndmask) * smprt
        flag = false;
    end
end

%% calculate PSF(Point Spread Function) // from fig.2
% Impulse
point = zeros(100,100);
point(51,51) = 1;

% PSF
kpnt = fft2c(point);
psf = kpnt.*rndmask;
tpsf = (1/smprt)*ifft2c(psf);

figure('Name', 'PSF'),
subplot(2,2,1), surf(abs(point)); title('Impulse(img)');
% subplot(2,2,2); imshow(abs(point),[0 5e-1]);
% subplot(2,2,3); surf(abs(tpsf)); title('PSF of random undersampling'); 
subplot(2,2,2); surf(abs(kpnt)); axis([1 100 1 100 0 5e-2]);
subplot(2,2,4); surf(abs(psf)); axis([1 100 1 100 0 5e-2]);
subplot(2,2,3); surf(abs(tpsf)); title('PSF of random undersampling'); 


%% TPSF(Transform Point Spread Function)

% 0. wavelet domain setting
wdp = 2;
[c,s]=wavedec2(zeros(100,100),wdp,'haar');
% impulse // (12,8) on V2
pntidx = sub2ind(s(2,:),12,8);
c(prod(s(1,:))+1*prod(s(2,:))+pntidx) = 1; 

[H1,V1,D1] = detcoef2('all',c,s,1);
A1 = appcoef2(c,s,'haar',1); 
[H2,V2,D2] = detcoef2('all',c,s,2);
A2 = appcoef2(c,s,'haar',2); 

% 1. impulse on wavelet domain
wdata = [A2 H2; V2 D2];
wdata = [wdata H1; V1 D1];
figure('Name', 'Impulse(wavelet)'), surf(abs(wdata));


% 2. IDWT(Inverse Discrete Wavelet Transform)
imgdata = waverec2(c,s,'haar');
figure('Name','IDWTed impulse(image)'), surf(abs(imgdata));
 
% 3. FFT
kdata = fft2c(imgdata);
figure('Name','FFTed impulse(kspace)'), surf(abs(kdata));

% 4. undersampling
rds = kdata.*rndmask;
figure('Name','undersampled impulse(kspace)'), surf(abs(rds));

% 4. IFFT
rdimg = (1/smprt)*ifft2c(rds);
figure('Name','iFFTed impulse(image)'), surf(abs(rdimg));

% 6. FDWT
[cw,sw] = wavedec2(rdimg,wdp,'haar');
[Hw1,Vw1,Dw1] = detcoef2('all',cw,sw,1);
Aw1 = appcoef2(cw,sw,'haar',1); 
[Hw2,Vw2,Dw2] = detcoef2('all',cw,sw,2);
Aw2 = appcoef2(cw,sw,'haar',2); 

wwdata = [Aw2 Hw2; Vw2 Dw2];
wwdata = [wwdata Hw1; Vw1 Dw1];
figure('Name', 'reconed Impulse(wavelet)'), surf(abs(wwdata));

%% Comparing TPSF's max and it's index
[orgm,orgi] = max(wdata(:)); % before transformed
[recm,reci] = max(wwdata(:)); % after transformed
fprintf('impulse val : %.2f // impulse idx :  %d \n',orgm, orgi)
fprintf('reconed val : %.2f // recon max idx :  %d \n',recm, reci)























