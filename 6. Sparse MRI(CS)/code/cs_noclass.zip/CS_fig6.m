clear all; close all; clc;
addpath(strcat(pwd,'/utils')); 
addpath(strcat(pwd,'/phantom'));
%% 1. load data
load im1
img = im1;

% normalising
img = img./max(abs(img(:)));
kdata = fft2c(img);

% sampling mask
pwrfct = 3;
pctg = 0.3;
[mask,pdf] = genrndmask_new(kdata,pwrfct,pctg);
% [mask,pdf] = genrndmask_1d(kdata,pwrfct,pctg); 

% %
% load brain512
% kdata = data;
% img = ifft2c(kdata);
% img = img/max(abs(img(:)));

% initial image
kdata = kdata.*mask;
img_init = ifft2c((kdata./pdf));

%% 2. Nonlinear CG with line backtracking
% iteration parameter
it_para.maxiter = 10;
it_para.gradtol = 1e-6;
it_para.alpha = 0.05;
it_para.beta = 0.6;
it_para.tmax = 100;

% wavelet parameter
w_para.lvl = 4;
w_para.filter = 'db1';
w_para.smoothingfct = 1e-6;
w_para.lambda = 0.005;

% fourier parameter
f_para.mask = mask;
f_para.pdf = pdf;

% TV parameter
tv_para.weight = 2e-3;
tv_para.smoothingfct = 1e-6;

% nonlinear CG
tic
[rec,rmse] = nlcg_new(kdata,it_para, w_para, f_para, tv_para);
toc

%% 3. plotting

tmp = cat(2,img,abs(img_init),abs(rec));

figure(), imshow(mask); title('undersampling mask');
figure(), imshow(abs(tmp),[]); title('REF, under, recon')
figure(), plot(rmse); title('RMSE'); xlabel('iteration'); ylabel('rmse')

%%
rmpath(strcat(pwd,'/utils')); 
rmpath(strcat(pwd,'/phantom'));