clear all; close all; clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PSF has a significant value at least it has enough sampled line on low
%  freq region.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% A input, unit impulse
x = zeros(100,1);
x(50) = 1;
figure, plot(1:100,abs(x)); title('Unit Impulse');


% The Fourier matrix
F = dftmtx(100);
um = ceil(rand(100,1)*100);
um = unique(um);
fprintf('non-sampled line : %d among 100\n',length(um));
F(um,:) = 0;
figure, imshow(abs(ifftshift(F)),[]); title('Undersampled Fourier Operator');


% k-space undersampling
Fue = ifftshift(F*fftshift(x));
figure, plot(1:100,abs(Fue))
title('Undersampled Fourier domain');
% 2-D visualized k-space
% figure, imshow(abs(repmat(Fue,1,100)),[])


% Inverse Fourier Transform
Fi = conj(F)/100;
FFe = ifftshift(Fi*fftshift(Fue));
figure, plot(1:100,abs(FFe)); title('Point Spread Function')

%%%
% Q1. Why a reconstructed signal shows imperfection when the undersampling
% includes few center lines?
%   => FT(delta) = boxcar in ft domain -> same E in everywhere. Then why?
%
%

