function [img_rec,rmse] = nlcg_new(kdata,it_para, w_para, f_para, tv_para)
%-----------------------------------------------------------------------
%
% img_rec = nlcg_new(kdata,it_para, w_para, f_para);
%
% implementation of a L1 penalized non linear conjugate gradient reconstruction
%
% The function solves the following problem:
%
% given k-space measurments y, and a fourier operator F the function 
% finds the image x that minimizes:
%
% f(x) = ||F* W' *x - y||^2 + lambda1*|x|_1
%
%
% the optimization method used is non linear conjugate gradient with fast&cheap backtracking
% line-search.
% 
%-------------------------------------------------------------------------

    img_rec = 0.*kdata;
    rmse = [];
%     img_rec = ifft2c((kdata./f_para.pdf));

    % iteration parameters
    maxit = it_para.maxiter;
    gradtol = it_para.gradtol;
    alpha = it_para.alpha;
    beta = it_para.beta;
    t_maxiter = it_para.tmax;

    g = grad(img_rec,kdata,w_para,f_para,tv_para);
    dm = -g;
    grd = g(:)'*g(:);
    
    for i = 1:maxit
        
        % stop condition
        rmse = [rmse g(:)'*g(:)/grd];
        if rmse(i) < gradtol
            break;
        end
        fprintf('%d-th iteration // gradient = %.6f\n', i,rmse(i));
    
        % backtraking line-search
        t = 1;
        t_iter = 0;
        f_obj = obj(img_rec+t*dm,kdata,w_para,f_para,tv_para);
        f_line = obj(img_rec,kdata,w_para,f_para,tv_para) - alpha*t*abs(g(:)'*dm(:));
        while ((f_obj > f_line) && (t_iter < t_maxiter))
            t = beta*t;
            f_obj = obj(img_rec+t*dm,kdata,w_para,f_para,tv_para);
            f_line = obj(img_rec,kdata,w_para,f_para,tv_para) - alpha*t*abs(g(:)'*dm(:));
            t_iter = t_iter + 1;
        end
        
        img_rec = img_rec + t*dm;
        g_nxt = grad(img_rec,kdata,w_para,f_para,tv_para);
        gamma = (g_nxt(:)'*g_nxt(:)) / (g(:)'*g(:));
        dm = -g_nxt + gamma*dm;
        
        g = g_nxt;
    end

end


function res = obj(img,kdata,w_para,f_para,tv_para)
    % data consistency term
    tmp_f = fft2c(img).*f_para.mask - kdata;
    tmp_f = tmp_f.*conj(tmp_f);
    
    % sparsity term
    [wav_img,widx] = wav2c(img,w_para.lvl,w_para.filter);
%     tmp_w = sqrt(wav_img.*conj(wav_img)+w_para.smoothingfct);
    tmp_w = wavshow(abs(wav_img),widx,w_para.filter);
    
    tv_img = D(img);
%     tmp_tv = sqrt(tv_img.*cong(tv_img)+tv_para.smoothingfct);
    tmp_tv = sqrt(tv_img.*conj(tv_img));
    
    res = sum(tmp_f(:)) + w_para.lambda*sum(tmp_w(:)) + tv_para.weight*sum(tmp_tv(:));
end

function df = grad(img,kdata,w_para,f_para,tv_para)
% F + lambda*W
% F = 2*F'(F(m)-y)
% W = Phi'*W-1*Phi(m)

    gradF = gObj(img,kdata,f_para);
    gradW = gWav(img,w_para);
    gradTV = gTV(img,tv_para);
    
    df = gradF + w_para.lambda.*gradW + tv_para.weight.*gradTV;
end

function res = gObj(img,kdata,f_para)
% 2*F'(F(m)-y)
    tmp = fft2c(img).*f_para.mask - kdata;
    res = ifft2c(tmp.*f_para.mask);
%     res = ifft2c((tmp.*f_para.mask)./f_para.pdf);
    res = 2*res;
end

function res = gWav(img,w_para)
% Phi'*W-1*Phi(m)
    [wav_img,widx] = wav2c(img,w_para.lvl,w_para.filter);
    smoothing = sqrt(wav_img .* conj(wav_img) + w_para.smoothingfct);
    tmp = wav_img./smoothing;
    res = iwav2c(tmp,widx,w_para.filter);
end

function res = gTV(img,tv_para)

    Dx = D(img);
    G = Dx./sqrt(Dx.*conj(Dx) + tv_para.smoothingfct);
    res = invD(G,size(img));
end

