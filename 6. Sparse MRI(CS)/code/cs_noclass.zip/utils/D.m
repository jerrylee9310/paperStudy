function res = D(img)

%
% dify = | ---  ( r2-r1 )  --- |  difx.' = | ---  ( c2-c1 )  --- |
%        |          .          |           |          .          |
%        |          .          |           |          .          |
%        |          .          |           |          .          |
%        | --- (r_n-r_n-1) --- |           | --- (c_n-c_n-1) --- |
%        | --   (r_n-r_n ) --  |           | --- (c_n-c_n-1) --- |
% 

dify = img([2:end,end],:) - img; 
difx = img(:,[2:end,end]) - img;

res = [sum(img(:))/sqrt(numel(img)); dify(:);  difx(:)]; % [avg; dify; difx]