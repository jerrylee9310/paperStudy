function [res,avg] = Dshow(tvdata,imsize)

avg = tvdata(1);
tvy = reshape(tvdata(2:prod(imsize)+1),imsize);
tvx = reshape(tvdata(prod(imsize)+2:end),imsize);
res = tvy+tvx;