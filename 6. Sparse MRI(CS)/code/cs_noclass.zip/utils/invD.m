function res = invD(y, imsize)

% y = Ax // in finite difference case,
% y : finite difference image, 
% x : originla image
% A : finite difference operator

% afun :  finite difference operator

[res, flag, relres, iter] = lsqr(@afun,y,[],150,[],[],[],imsize);

res = reshape(res,imsize);

function res = afun(x, imsize, istranspose)

if nargin==2
    x = reshape(x,imsize(1), imsize(2));
    res = D(x);
else
    res = adjD(x,imsize);
    res = res(:);
end
